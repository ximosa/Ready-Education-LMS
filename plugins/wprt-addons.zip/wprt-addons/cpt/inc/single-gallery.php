<?php get_header(); ?>

<div id="content-wrap" class="edukul-container">
    <div id="site-content" class="site-content single-gallery clearfix">
        <div id="inner-content" class="inner-content-wrap">

			<div class="gallery-detail-wrap">
				<?php while ( have_posts() ) : the_post();
					the_content();
				endwhile; ?>
			</div>

        </div><!-- /#inner-content -->
    </div><!-- /#site-content -->
</div><!-- /#content-wrap -->

<?php get_footer(); ?>