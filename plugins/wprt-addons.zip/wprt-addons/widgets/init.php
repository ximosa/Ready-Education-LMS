<?php 

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

require_once __DIR__ . '/twitter.php';
require_once __DIR__ . '/spacer.php';
require_once __DIR__ . '/socials.php';
require_once __DIR__ . '/instagram.php';
require_once __DIR__ . '/recentposts.php';
require_once __DIR__ . '/contact-form-7.php';
require_once __DIR__ . '/links.php';
require_once __DIR__ . '/information.php';

?>